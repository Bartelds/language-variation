# Notes on import functions:
#
# Input files can have empty lines, or lines starting with '#'
# (possibly preceded by white space). These lines should be skipped.
#
# Labels can have spaces, and there are no quotes around labels.
# Leading and trailing white space should be removed.
#
# Default file encoding for read/write functions is iso-8859-1, because
# that is what L04 PostScript programs expect.

read.dif <- function(file, encoding="iso-8859-1") {
    if (is.character(file)) {
        filename <- TRUE
        con <- file(file, open="rt", encoding=encoding)
    } else {
        filename <- FALSE
        con <- file
    }

    # # using comment.char truncates labels with '#' in it
    #if (any(names(formals(scan)) == "comment.char")) {
    #    a <- scan(file = con,
    #              what = "",
    #              sep = "\n",
    #              strip.white = c(TRUE),
    #              blank.lines.skip = TRUE,
    #              quiet = TRUE,
    #              comment.char = "#")
    #} else {
        a <- scan(file = con,
                  what = "",
                  sep = "\n",
                  strip.white = c(TRUE),
                  blank.lines.skip = TRUE,
                  quiet = TRUE)
        a <- a[substr(a, 1, 1) != '#']
    #}

    if (filename) {
        close(con)
    }

    size <- as.numeric(a[1])
    if (is.na(size))
        stop("Missing table size")
    if (length(a) != 1 + size + (size * size - size) / 2)
        stop("Illegal table size")
    dif <- matrix(NA, size, size)
    dif[row(dif) < col(dif)] <- as.numeric(a[(1 + size + 1):(1 + size + (size * size - size) / 2)])
    dif <- as.dist(t(dif))

    attr(dif, "Labels") <- a[(1 + 1):(1 + size)]

    dif
}

write.dif <- function(dif, file, encoding="iso-8859-1") {
    if (is.character(file)) {
        filename <- TRUE
        con <- file(file, open="wt", encoding=encoding)
    } else {
        filename <- FALSE
        con <- file
    }

    m <- as.matrix(dif)
    cat(nrow(m),
        rownames(m),
        m[row(m) < col(m)],
        sep = "\n",
        file = con)

    if (filename) {
        close(con)
    }
}

read.vec <- function(file, encoding="iso-8859-1") {
    if (is.character(file)) {
        filename <- TRUE
        con <- file(file, open="rt", encoding=encoding)
    } else {
        filename <- FALSE
        con <- file
    }

    # # using comment.char truncates labels with '#' in it
    #if (any(names(formals(scan)) == "comment.char")) {
    #    a <- scan(file = file,
    #              what = "",
    #              sep = "\n",
    #              strip.white = c(TRUE),
    #              blank.lines.skip = TRUE,
    #              quiet = TRUE,
    #              comment.char = "#")
    #} else {
        a <- scan(file = con,
                  what = "",
                  sep = "\n",
                  strip.white = c(TRUE),
                  blank.lines.skip = TRUE,
                  quiet = TRUE)
        a <- a[substr(a, 1, 1) != '#']
    #}

    if (filename) {
        close(con)
    }

    size <- as.numeric(a[1])
    if (is.na(size))
        stop("Missing vector size")
    if ((length(a) - 1) %% (size + 1) != 0)
      stop("Illegal file size")
    n <- (length(a) - 1) %/% (size + 1)
    if (size == 1) {
        m <- 0
    } else {
        m <- 2
    }
    v <- matrix(as.numeric(a[c(FALSE, 2:length(a) %% (size + 1) != m)]),
                nrow = n,
                ncol = size,
                byrow = TRUE)
    rownames(v) <- a[1:length(a) %% (size + 1) == m]
    v
}

write.vec <- function(vec, file, encoding="iso-8859-1") {
    if (is.character(file)) {
        filename <- TRUE
        con <- file(file, open="wt", encoding=encoding)
    } else {
        filename <- FALSE
        con <- file
    }

    cat(ncol(vec),
        t(matrix(c(rownames(vec), vec), nrow(vec), ncol(vec) + 1)),
        file = con,
        sep = "\n")

    if (filename) {
        close(con)
    }
}

MDS <- function(dif, dim) {
    a <- cmdscale(dif, k = dim, eig = FALSE)
    row.names(a) <- attr(dif, "Labels")
    a
}

SAMMON <- function(dif, dim, ...) {
    a <- sammon(dif, k = dim, ...)$points
    row.names(a) <- attr(dif, "Labels")
    a
}

ISOMDS <- function(dif, dim, y = cmdscale(dif, dim), ...) {
    if (any(names(formals(isoMDS)) == "k"))
        a <- isoMDS(dif, y = y, k = dim, ...)$points   # MASS >= 6.3-1
    else
        a <- isoMDS(dif, y = y, ...)$points            # MASS <  6.3-1
    row.names(a) <- attr(dif, "Labels")
    a
}

mean.asp <- function(...) {
    y1 <- min(..., na.rm = TRUE) / 180 * pi
    y2 <- max(..., na.rm = TRUE) / 180 * pi
    if (y2 - y1 < .001) {
        1 / cos ((y1 + y2) / 2)
    } else {
        (y2 - y1) / (sin (y2) - sin (y1))
    }
}

clustermap <- function(coo, dst, method = "ward.D2", k = 2, col = rainbow(k),
                       labels = "dots", cex = 1, seq = 25:1, bwlim = .55, map = NULL,
                       xlab = NULL, ylab = NULL, ...) {
    n <- rownames(coo)
    t <- cutree(hclust(dst, method = method), k = k)
    g <- t[n]
    s <- sapply(col, col2rgb)
    BW <- ifelse(.3 * s[1, ] + .59 *  s[2, ] + .11 *  s[3, ] > 255 * bwlim, "black", "white")
    if (is.null (map)) {
        x = range(coo[, 1], na.rm = TRUE)
        y = range(coo[, 2], na.rm = TRUE)
    } else {
        x = range(map[, 1], na.rm = TRUE)
        y = range(map[, 2], na.rm = TRUE)
    }
    if (is.null(xlab)) {
        xlab <- names(coo)[1]
    }
    if (is.null(ylab)) {
        ylab <- names(coo)[2]
    }
    plot(x, y, type = "n", xlab = xlab, ylab = ylab, ...)
    for (size in seq) points(coo[, 1:2], col = col[g], pch = 16, cex = size)
    if (! is.null (map)) {
        lines (map)
    }
    if (length(labels) > 1) {
        text(coo[, 1:2], labels = labels, col = BW[g], cex = cex)
    } else if (labels == "names") {
        text(coo[, 1:2], labels = n, col = BW[g], cex = cex)
    } else if (labels == "dots") {
        points(coo[, 1:2], pch = 16, col = BW[g], cex = cex)
    } else if (labels != "none") {
        stop("Invalid value for argument \"labels\"")
    }
}

mdsmap <- function(coo, mds, labels = "dots", cex = 1, seq = 25:1, bwlim = .55, map = NULL,
                   xlab = NULL, ylab = NULL, eqrgb = FALSE, ...) {
    n <- rownames(coo)

    if (eqrgb) {
        mr <- max(mds[n, 1]) - min(mds[n, 1])
        mg <- max(mds[n, 2]) - min(mds[n, 2])
        mb <- max(mds[n, 3]) - min(mds[n, 3])
        m  <- max(mr, mg, mb)
        red   <- (1 - mr / m) / 2 + (mds[n, 1] - min(mds[n, 1])) / m
        green <- (1 - mg / m) / 2 + (mds[n, 2] - min(mds[n, 2])) / m
        blue  <- (1 - mb / m) / 2 + (mds[n, 3] - min(mds[n, 3])) / m
    } else {
        red   <- (mds[n, 1] - min(mds[n, 1])) / (max(mds[n, 1]) - min(mds[n, 1]))
        green <- (mds[n, 2] - min(mds[n, 2])) / (max(mds[n, 2]) - min(mds[n, 2]))
        blue  <- (mds[n, 3] - min(mds[n, 3])) / (max(mds[n, 3]) - min(mds[n, 3]))
    }
    Col <- rgb(red, green, blue)
    BW <- ifelse(.3 * red + .59 * green + .11 * blue > bwlim, "black", "white")
    if (is.null (map)) {
        x = range(coo[, 1], na.rm = TRUE)
        y = range(coo[, 2], na.rm = TRUE)
    } else {
        x = range(map[, 1], na.rm = TRUE)
        y = range(map[, 2], na.rm = TRUE)
    }
    if (is.null(xlab)) {
        xlab <- names(coo)[1]
    }
    if (is.null(ylab)) {
        ylab <- names(coo)[2]
    }
    plot(x, y, type = "n", xlab = xlab, ylab = ylab, ...)
    for (size in seq) points(coo[, 1:2], col = Col, pch = 16, cex = size)
    if (! is.null (map)) {
        lines (map)
    }
    if (length(labels) > 1) {
        text(coo[, 1:2], labels = labels, col = BW, cex = cex)
    } else if (labels == "names") {
        text(coo[, 1:2], labels = n, col = BW, cex = cex)
    } else if (labels == "dots") {
        points(coo[, 1:2], pch = 16, col = BW, cex = cex)
    } else if (labels != "none") {
        stop("Invalid value for argument \"labels\"")
    }
}

cccmap <- function(coo, dst, n = 50, noise = .5,
                       labels = "dots", cex = 1, seq = 25:1, bwlim = .55, map = NULL,
                       xlab = NULL, ylab = NULL, eqrgb = TRUE, ...) {

    len <- length(dst)
    size <- attributes(dst)$Size
    SD <- sd(dst)

    co <- as.dist(matrix(0, size, size))
    attr(co, "Labels") <- names(dst)

    v <- 0
    if (interactive ()) {
        if (.Platform$OS.type == "unix") {
            v <- 1
        } else if (.Platform$OS.type == "windows") {
            v <- 2
        }
    }

    if (v == 2) { cat("Busy") ; flush.console() }
    for (i in 1:n) {
        if (v == 1) cat(" ", n - i + 1, " \r")
        if (v == 2) { cat(".") ; flush.console() }
        dst2 <- dst + runif(len, 0, noise * SD)
        co <- co + cophenetic(hclust(dst2, "average"))
        dst2 <- dst + runif(len, 0, noise * SD)
        co <- co + cophenetic(hclust(dst2, "mcquitty"))
    }
    co <- co / (2 * n)

    if (v == 1) cat ("   \r")
    if (v == 2) cat ("done\n")

    mdsmap(coo, MDS(co, 3),
        labels = labels, cex = cex, seq = seq, bwlim = bwlim, map = map, xlab = xlab, ylab = ylab, eqrgb = eqrgb, ...)
}

linkmap <- function(coo, dst, labels = "dots", cex = 1, limit = .25,
                    shift = .2, separate = 10, asp = NA, nmax = NA, map = NULL,
                    xlab = NULL, ylab = NULL, col = gray(0:40/40), ...) {
    if (is.null (map)) {
        x = range(coo[, 1], na.rm = TRUE)
        y = range(coo[, 2], na.rm = TRUE)
    } else {
        x = range(map[, 1], na.rm = TRUE)
        y = range(map[, 2], na.rm = TRUE)
    }
    if (is.null(xlab)) {
        xlab <- names(coo)[1]
    }
    if (is.null(ylab)) {
        ylab <- names(coo)[2]
    }
    plot(x, y, type = "n", asp = asp, xlab = xlab, ylab = ylab, ...)

    m <- as.matrix(dst)
    l <- length(m[, 1])
    d <- m[col(m) < row(m)]
    a <- 1:l
    names(a) <- rownames(coo)
    n <- matrix(rep(a[rownames(m)], l), l, l)
    rm(a, l, m)
    i <- n[col(n) < row(n)]
    n <- t(n)
    j <- n[col(n) < row(n)]
    rm(n)

    l1 <- min(d)
    l2 <- max(d)
    g <- (d - l1) / (l2 - l1)
    g <- as.integer( (1 / (1 + exp(- separate * (g - shift)))) * length(col) + .5)
    rm(l1, l2)

    if (is.na(asp))
        asp <- 1
    dx <- (max(coo[, 1]) - min(coo[, 1])) / asp
    dy <-  max(coo[, 2]) - min(coo[, 2])
    dd <- limit * sqrt((dx * dx + dy * dy))

    if (is.na (nmax)) {
        first <- 1
    } else {
        first <- length(d) - nmax + 1
        if (first < 1)
            first <- 1
    }

    o <- rev(order(d))
    for (n in o[first:(length(o))]) {
        x1 <- coo[i[n], 1]
        x2 <- coo[j[n], 1]
        y1 <- coo[i[n], 2]
        y2 <- coo[j[n], 2]
        dx <- (x1 - x2) / asp
        dy <- (y1 - y2)
        if (sqrt(dx * dx + dy * dy) <= dd)
            lines(c(x1, x2), c(y1, y2), col = col[g[n]], lwd = 4)
    }

    if (! is.null (map)) {
        lines (map)
    }

    if (length(labels) > 1) {
        text(coo[, 1:2], labels = labels, cex = cex, col = "red", font = 2)
    } else if (labels == "names") {
        text(coo[, 1:2], labels = rownames(coo), cex = cex, col = "red", font = 2)
    } else if (labels == "dots") {
        points(coo[, 1:2], pch = 16, cex = 1.5 * cex, col = "white")
        points(coo[, 1:2], pch = 16, cex = cex)
    } else if (labels != "none") {
        stop("Invalid value for argument \"labels\"")
    }
}
