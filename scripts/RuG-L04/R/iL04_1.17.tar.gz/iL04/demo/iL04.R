require(iL04)
opar <- par(ask = TRUE)
data(PA)
data(PA.coo)
data(PA.map)
asp <- mean.asp(PA.map[, 2])
rownames(PA.coo[order(PA.coo$idx), ])
clustermap(PA.coo[, 1:2], PA, labels = PA.coo$idx, k = 4,
           main = "Pennsylvania, USA",
           asp = asp, map = PA.map)
mds <- MDS(PA, 3)
mdsmap(PA.coo[, 1:2], mds, labels = PA.coo$idx,
       main = "Pennsylvania, USA",
       asp = asp, map = PA.map)
cccmap(PA.coo[, 1:2], PA, labels = PA.coo$idx,
       main = "Pennsylvania, USA",
       asp = asp, map = PA.map)
linkmap(PA.coo[, 1:2], PA, labels = PA.coo$idx,
        main = "Pennsylvania, USA",
        nmax = 600, limit = .2, separate = 20, asp = asp, map = PA.map)
par(opar)
